package com.example.limitsspringcloudconfigserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LimitsSpringCloudConfigServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(LimitsSpringCloudConfigServerApplication.class, args);
	}

}
