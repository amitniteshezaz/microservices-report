package com.example.limitsspringcloudconfigserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LimitsSpringCloudConfigServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
