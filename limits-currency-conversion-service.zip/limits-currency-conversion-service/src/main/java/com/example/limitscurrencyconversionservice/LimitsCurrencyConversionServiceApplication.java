package com.example.limitscurrencyconversionservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LimitsCurrencyConversionServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(LimitsCurrencyConversionServiceApplication.class, args);
	}

}
