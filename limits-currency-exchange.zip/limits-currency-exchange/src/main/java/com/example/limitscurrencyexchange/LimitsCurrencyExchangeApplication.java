package com.example.limitscurrencyexchange;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LimitsCurrencyExchangeApplication {

	public static void main(String[] args) {
		SpringApplication.run(LimitsCurrencyExchangeApplication.class, args);
	}

}
