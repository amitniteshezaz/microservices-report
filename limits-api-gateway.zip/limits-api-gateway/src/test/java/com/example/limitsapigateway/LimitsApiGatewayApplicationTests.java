package com.example.limitsapigateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LimitsApiGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
