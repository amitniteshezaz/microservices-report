package com.example.limitsapigateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LimitsApiGatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(LimitsApiGatewayApplication.class, args);
	}

}
